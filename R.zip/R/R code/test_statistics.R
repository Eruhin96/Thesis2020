#normal
prices <- sample(EuStockMarkets[,4], 1000, replace=FALSE)
log_returns <- diff(log(prices), lag=1)
qqplot((log_returns), rnorm(1000))


#t-distribution
students <- read.csv("https://userpage.fu-berlin.de/soga/200/2010_data_sets/students.csv")
salary <- sample(unique(students$weight), 5000, replace=TRUE)
qqnorm(salary )
qqplot(rnorm(5000),normal_salary)


#chisq
exp_salary <- sample(unique(students$salary) * 2, 5000, replace=TRUE) 
qqplot(rchisq(5000,50), exp_salary)

#gamma
weekly<-read.csv("sales_data.csv")
weekly_sales_subset <- sample(weekly$Weekly_Sales, 10000, replace =  FALSE)
hist(weekly_sales_subset)
qqplot(rgamma(10000,0.5,0.1),weekly_sales_subset)

#normal
prices <- sample(EuStockMarkets[,4], 1500, replace=FALSE)
log_returns <- diff(log(prices), lag=1)
qqplot((log_returns), rt(1500,21))


########################################################################################
#############3 "BINOM AND POISSON VALIDATE USING PAPERS AND SOURCES"#####################
#poisson
pois<- read.csv("poisson_sim.csv")
pois_math <-  sample(pois$num_awards,500, replace = TRUE)
qqplot(rpois(500,12), rpois(500,1))
qqplot(rpois(500,50),pois_math)

#binom
num_dice <- c(1,2,3,4,5,6) 
binom_dice <- sample(num_dice,1000, replace= TRUE, prob = c(1/6,1/6,1/6,1/6,1/6,1/6))
qqplot(rbinom(1000,6,1/6), binom_dice)
qqnorm(rbinom(1000,6,1/6))
qqnorm(binom_dice)



