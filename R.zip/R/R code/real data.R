library("carData")

prices <- sample(EuStockMarkets[,4], 1000, replace=TRUE)
log_returns <- diff(log(prices), lag=1)
qqnorm(log_returns)
qqline(log_returns * log_returns)
qqplot(rnorm(1000),log_returns)

#normal distribution
objects <- c(1:100)
for (i in 1: length(objects)) {
  jpeg(paste("chisq",objects[i], ".jpg", sep=""))
  prices <- sample(EuStockMarkets[,4], 1000, replace=TRUE)
  log_returns <- diff(log(prices), lag=1)
  qqnorm(log_returns)
  qqline(log_returns)
  dev.off()
}

#chisq distribution
objects <- c(1:100)
for (i in 1: length(objects)) {
  jpeg(paste("chisq",objects[i], ".jpg", sep=""))
  prices <- sample(EuStockMarkets[,4], 1000, replace=TRUE)
  log_returns <- diff(log(prices), lag=1)
  qqnorm(log_returns * log_returns)
  qqline(log_returns * log_returns)
  dev.off()
}



# student data
students <- read.csv("https://userpage.fu-berlin.de/soga/200/2010_data_sets/students.csv")
males <- subset(students, gender=='Male')
females <- subset(students, gender=='Female')
iq_score <- read.csv("Wong.csv")

# t-distribution
salary <- sample(students$salary, 10000, replace=TRUE)
qqnorm(salary )
qqnorm(students$salary)

objects <- c(51:100)
for (i in 1: length(objects)) {
  jpeg(paste("t-distribution",objects[i], ".jpg", sep=""))
  normal_salary <- rt(5000,10)
  qqnorm(normal_salary )
  qqline(normal_salary)
  dev.off()
}

# chisq distribution
objects <- c(1:100)
for (i in 1: length(objects)) {
  jpeg(paste("chisq_real",objects[i], ".jpg", sep=""))
  exp_salary <- sample(students$salary, 5000, replace=TRUE)
  qqnorm(exp_salary * exp_salary)
  qqline(exp_salary * exp_salary)
  dev.off()
}

# poisson distribution
objects <- c(101:200)
for (i in 1: length(objects)) {
  jpeg(paste("poisson_real",objects[i], ".jpg", sep=""))
  poi_math <-  sample(pois$num_awards,500, replace = TRUE)
  qqnorm(poi_math)
  qqline(pois$num_awards)
  dev.off()
}


income <- read.csv("kaggle_income.csv")
vc <-sample(income$Zip_Code,5000, replace = TRUE)
qqnorm(vc)

#uniform
objects <- c(1:100)
for (i in 1: length(objects)) {
  jpeg(paste("uniform_real",objects[i], ".jpg", sep=""))
  unform_zip <- sample(income$Zip_Code,5000, replace = TRUE)
  qqnorm(unform_zip)
  qqline(unform_zip)
  dev.off()
}


#binomial
objects <- c(101:200)
for (i in 1: length(objects)) {
  jpeg(paste("binom",objects[i], ".jpg", sep=""))
  num_dice <- c(1,2,3,4,5,6) 
  binom_dice <- sample(num_dice,1000, replace= TRUE, prob = c(1/i,1/i,1/i,1/i,1/i,1/i))
  qqnorm(binom_dice)
  qqline(binom_dice)
  dev.off()
}

weekly<-read.csv("sales_data.csv")
qqnorm(rchisq(5000,2))
qqnorm(rgamma(5000,0.5,0.1))


weekly_sales_subset <- sample(weekly$Weekly_Sales, 10000, replace =  TRUE)
qqplot(weekly_sales_subset, rgamma(10000,0.5,0.5)) # they form a relatiev straight line so its a go
#gamma
objects <- c(1:100)
for (i in 1: length(objects)) {
  jpeg(paste("gamma",objects[i], ".jpg", sep=""))
  weekly_sales_subset <- sample(weekly$Weekly_Sales, 1000, replace =  TRUE)
  qqnorm(weekly_sales_subset)
  qqline(weekly_sales_subset)
  dev.off()
}




#plots for paper
plot(density(runif(1000000)), main = "", xlab = "", ylab = "" )
plot(density(rgamma(10000000,4, 5)), main = "", xlab = "", ylab = "" )
plot(density(rgamma(1000000,4, 0.5)),main = "", xlab = "", ylab = "" )
plot(density(rchisq(1000000,20)),main = "", xlab = "", ylab = "" )
plot(density(rt(1000000,60)),main = "", xlab = "", ylab = "" )
plot(density(rnorm(1000000)),main = "", xlab = "", ylab = "" )
plot(density(rpois(1000000,50)),main = "", xlab = "", ylab = "" )
plot(density(rbinom(1000000,10, 0.5)),main = "", xlab = "", ylab = "" )
qqnorm(rbinom(100000,100, 0.25), main = "", xlab = "" , ylab = "")


     