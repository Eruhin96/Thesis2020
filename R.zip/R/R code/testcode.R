objects <- c(21:50)
for (i in 1: length(objects)) {
  jpeg(paste("test",objects[i], ".jpg", sep=""))
  distribution<- rpois(156,3)
  qqnorm(distribution)
  qqline(distribution)
  dev.off()
}
qqnorm(rchisq(100,6))
runif()
rchisq()




 #smalla data {100,500, 1000}

#big number of poisson leads to straight linr
plot(rnorm(100))
abline(rnorm(100))
qqnorm(rbinom(900,50,1/2))
boxplot(rnorm(1000))
boxplot(rt(1000,40))
qqnorm(rbinom(300,10,1/2))
qqnorm(rgamma(100,1,1))
x<- as.matrix(body.dat)
qqnorm(x[,24])
qqline(x[,24])

qqnorm(rnorm(500), main = NULL)
qqnorm(rt(500,50),main = NULL)

qqnorm(rgamma(500,1,0.5),main = NULL)
qqnorm(rchisq(500,2), main = NULL)



#real world data
my_data1 <- as.matrix(AirPassengers)
v <- sample(my_data1, 100, replace=TRUE)
qqnorm(v)


v2 <- sample(EuStockMarkets[,4], 1000, replace=TRUE)
qqnorm(v2)

mydata3 <- as.matrix(LifeCycleSavings)
v3 <- sample(mydata3[,4], 1000, replace=TRUE)
qqnorm(v3)

mydata4 <- as.matrix(ChickWeight)

v4<-sample(ChickWeight[,1],100, replace = TRUE)
qqnorm(v4)

males <- subset(students, gender=='Male')
females <- subset(students, gender=='Female')

prices <- EuStockMarkets[,4]
log_returns <- diff(log(prices), lag=1)
qqnorm(log_returns)

students <- read.csv("https://userpage.fu-berlin.de/soga/200/2010_data_sets/students.csv")
normal <- sample(males$weight,1000, replace = FALSE)
qqnorm(normal)
qqline(normal)

bread_vianna<-read.table("Vienna_Bread.csv", sep = ',', fill = TRUE, header= FALSE)
bread_vianna$V4
income <- read.csv("kaggle_income.csv")

albama <- subset(income,state.name == 'Alabama')
qqnorm(albama$Mean)

trainh <- read.csv("full_trains.csv")
qqnorm(trainh$delay_cause_travelers)
