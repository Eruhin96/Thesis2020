#this is the R code that was used to generate the QQ plots


generate_plots<-function(number, name, rdsmgn){
  jpeg(paste(name,number, ".jpg", sep=""))
  distribution<- rdsmgn
  qqnorm(distribution)
  qqline(distribution)
  dev.off()
  
}
objects <- c(1:100)
objects2 <- c(101:200)
objects3 <- c(201:300)
objects4 <- c(301:400)
objects5 <- c(401:500)

#merely change the name, and the random sample generator
for (i in 1: length(objects)) {
  generate_plots(objects[i], "test", rnorm(100))
  generate_plots(objects2[i], "test", rnorm(300))
  generate_plots(objects3[i], "test", rnorm(500))
  generate_plots(objects4[i], "test", rnorm(900))
  generate_plots(objects5[i], "test", rnorm(1500))
}


